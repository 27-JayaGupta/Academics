#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/sched.h>
#include <linux/kprobes.h>
#include<linux/binfmts.h>

static int __kprobes before(struct kprobe *p, struct pt_regs *regs)
{
  struct linux_binprm *bprm = (struct linux_binprm *)regs->di;
  printk(KERN_INFO "Exec is called and mm is initialized for %d execfile %s\n", current->pid, bprm->filename);
  return 0;	
}

static struct kprobe kp = {
        .symbol_name   = "load_elf_binary",
	.pre_handler = before,
	.post_handler = NULL,
};

int init_module(void)
{
	int ret;
	printk(KERN_INFO "Setting the probe\n");
	ret = register_kprobe(&kp);
        if (ret < 0) {
                printk(KERN_INFO "register_kprobe failed, returned %d\n", ret);
                return ret;
        }
        printk(KERN_INFO "Planted kprobe at %lx\n", (unsigned long)kp.addr);
        return 0;
}

void cleanup_module(void)
{
        unregister_kprobe(&kp);
	printk(KERN_INFO "Removed the probe\n");
}
MODULE_LICENSE("GPL");
